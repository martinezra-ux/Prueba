# Alertas, monitorización y seguridad

## A) Alerta si se cae la web (lo más rápido, 5 minutos y gratis)
1. Crea cuenta en https://uptimerobot.com (plan gratuito).
2. "Add New Monitor" > tipo **HTTP(s)** > URL `https://cancha-resultados-directo.netlify.app` > intervalo **5 minutos**.
3. En "Alert Contacts" añade `helpcancha.fut@gmail.com` y asócialo al monitor.
4. Crea un segundo monitor de tipo **Keyword** sobre la misma URL con la palabra `Cancha` (avisa si la web carga pero vacía).
5. Opcional: en Better Stack (betterstack.com) puedes añadir llamada/SMS gratis a cambio de más configuración.

## B) Vigilante de los servidores (ESPN, SportScore, Supabase) con aviso solo al cambiar
1. Ejecuta en Supabase: `supabase-preferencias.sql`, `supabase-notificaciones.sql` y `supabase-admin-monitorizacion.sql`.
2. Crea la función `watchdog` con `functions/watchdog/index.ts` (`supabase functions deploy watchdog`).
3. Secretos: `SERVICE_ROLE_KEY`, `PUBLISHABLE_KEY` (la clave pública de `cancha-account-config.js`) y
   - para avisos por **Telegram** (gratis, sin dominio): `TELEGRAM_TOKEN` (de @BotFather) y `TELEGRAM_CHAT_ID`;
   - o por **correo**: `RESEND_API_KEY`, `MAIL_FROM` y `ALERT_EMAIL` (por defecto helpcancha.fut@gmail.com). Requiere dominio verificado.
4. Prográmala cada 5 minutos. Te avisa cuando algo cae ("🔴") y cuando se recupera ("✅"), sin repetir mensajes.

## C) Panel de administración
1. Ejecuta `supabase-admin-monitorizacion.sql` y, en la última línea comentada, pon el correo de TU cuenta de Cancha y ejecútala.
2. Sube `admin.html` a Netlify y entra en `https://cancha-resultados-directo.netlify.app/admin.html`.
3. Muestra usuarios, equipos más seguidos, errores de la web, fallos de datos externos, tiempos de carga y estado de los servicios.
   Los datos están protegidos por permisos en la base de datos: sin ser administradora no se ve nada, aunque alguien conozca la dirección.

## D) Qué hace ya la web (sin configurar nada)
- **Caché y respaldo:** guarda las respuestas de ESPN y SportScore unos segundos o minutos, evita peticiones repetidas y,
  si el servicio falla, enseña la última copia guardada (hasta 24 h).
- **Monitorización:** envía de forma anónima los errores de la web, los fallos de datos y los tiempos de carga a la tabla `cancha_client_events`
  (sin datos personales). Hay que mencionarlo en la política de privacidad.
- **Analítica:** envía eventos (cambio de sección, equipo, partido y favoritos) al Google Tag Manager; el aviso de cookies controla si se usan.
  Para verlos en Google Analytics, crea en GTM etiquetas de evento GA4 que se activen con los eventos `cancha_*`.
- **Contraseñas:** al registrarse o cambiarla exige 10 caracteres, rechaza las muy comunes y las que aparecen en filtraciones conocidas
  (comprobación anónima en Have I Been Pwned).

## E) Ajustes de seguridad que solo puedes hacer tú en Supabase (Authentication)
- Longitud mínima de contraseña: 10 o más. Confirmación de correo: activada.
- Protección contra contraseñas filtradas (según tu plan) y límites de intentos (Rate limits) activados.
- CAPTCHA (hCaptcha o Cloudflare Turnstile) en registro e inicio de sesión: reduce cuentas falsas.
- Plantilla de correo de "contraseña cambiada" activada.
- Nunca pongas en la web ni en el chat la clave `service_role`/secret. La clave `publishable` es pública por diseño; su seguridad depende de los permisos (RLS) de las tablas, que los SQL ya incluyen.
- Si una clave secreta se filtra: genérala de nuevo en Supabase > Settings > API.
- Pendiente para más adelante: verificación en dos pasos (MFA) y política CSP estricta; requieren cambiar el inicio de sesión y probar con AdSense.
