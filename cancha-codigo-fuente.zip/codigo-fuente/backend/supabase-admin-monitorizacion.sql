-- Cancha.fut · monitorización y panel de administración (Supabase > SQL Editor > Run)
-- Orden: 1) supabase-preferencias.sql  2) supabase-notificaciones.sql  3) este archivo.

create table if not exists public.cancha_client_events (
  id bigserial primary key,
  created_at timestamptz not null default now(),
  kind text not null,
  message text,
  path text,
  ua text,
  value jsonb
);
create index if not exists cancha_client_events_created on public.cancha_client_events (created_at desc);
alter table public.cancha_client_events enable row level security;

create table if not exists public.cancha_admins (user_id uuid primary key references auth.users(id) on delete cascade);
alter table public.cancha_admins enable row level security;

create table if not exists public.cancha_alert_state (name text primary key, down boolean not null default false, updated_at timestamptz not null default now());
alter table public.cancha_alert_state enable row level security; -- sin políticas: solo la función de alertas

create or replace function public.is_admin() returns boolean language sql stable security definer set search_path = public as
$$ select exists (select 1 from public.cancha_admins where user_id = auth.uid()) $$;
revoke all on function public.is_admin() from public;
grant execute on function public.is_admin() to authenticated;

drop policy if exists "events_insert" on public.cancha_client_events;
create policy "events_insert" on public.cancha_client_events for insert to anon, authenticated
  with check (kind in ('js_error','api_fail','perf') and char_length(coalesce(message,'')) <= 400
    and char_length(coalesce(path,'')) <= 200 and char_length(coalesce(ua,'')) <= 200 and pg_column_size(value) < 2000);
drop policy if exists "events_select_admin" on public.cancha_client_events;
create policy "events_select_admin" on public.cancha_client_events for select to authenticated using (public.is_admin());
drop policy if exists "events_delete_admin" on public.cancha_client_events;
create policy "events_delete_admin" on public.cancha_client_events for delete to authenticated using (public.is_admin());
drop policy if exists "admins_self" on public.cancha_admins;
create policy "admins_self" on public.cancha_admins for select to authenticated using (user_id = auth.uid());

grant insert on public.cancha_client_events to anon, authenticated;
grant select, delete on public.cancha_client_events to authenticated;
grant usage on sequence public.cancha_client_events_id_seq to anon, authenticated;
grant select on public.cancha_admins to authenticated;

create or replace function public.admin_overview() returns jsonb language plpgsql stable security definer set search_path = public, auth as
$$
declare r jsonb;
begin
  if not public.is_admin() then raise exception 'forbidden'; end if;
  select jsonb_build_object(
    'users_total', (select count(*) from auth.users),
    'users_7d', (select count(*) from auth.users where created_at > now() - interval '7 days'),
    'users_24h_active', (select count(*) from auth.users where last_sign_in_at > now() - interval '24 hours'),
    'with_favorites', (select count(*) from public.cancha_user_preferences where jsonb_array_length(to_jsonb(favorite_teams)) > 0),
    'push_subs', (select count(*) from public.cancha_push_subscriptions),
    'email_digest', (select count(*) from public.cancha_email_prefs where daily_digest),
    'top_teams', (select coalesce(jsonb_agg(x), '[]') from (
        select coalesce(max(to_jsonb(p.team_data)->t.id->>'name'), t.id) as name, count(*) as n
        from public.cancha_user_preferences p, jsonb_array_elements_text(to_jsonb(p.favorite_teams)) as t(id)
        group by t.id order by n desc limit 15) x),
    'events_24h', (select coalesce(jsonb_agg(x), '[]') from (select kind, count(*) as n from public.cancha_client_events where created_at > now() - interval '24 hours' group by kind) x),
    'api_fail_24h', (select coalesce(jsonb_agg(x), '[]') from (select message as host, count(*) as n from public.cancha_client_events where kind = 'api_fail' and created_at > now() - interval '24 hours' group by message order by n desc) x),
    'perf_24h', (select jsonb_build_object('n', count(*),
        'lcp_p50', percentile_cont(.5) within group (order by (value->>'lcp')::float),
        'lcp_p90', percentile_cont(.9) within group (order by (value->>'lcp')::float),
        'load_p50', percentile_cont(.5) within group (order by (value->>'load')::float))
        from public.cancha_client_events where kind = 'perf' and created_at > now() - interval '24 hours' and value->>'lcp' is not null),
    'errors', (select coalesce(jsonb_agg(x), '[]') from (select created_at, message, path, ua from public.cancha_client_events where kind = 'js_error' order by created_at desc limit 30) x)
  ) into r;
  return r;
end $$;
revoke all on function public.admin_overview() from public;
grant execute on function public.admin_overview() to authenticated;

-- Hazte administrador (cambia el correo por el de TU cuenta de Cancha) y ejecuta SOLO esta línea:
-- insert into public.cancha_admins select id from auth.users where email = 'TU_CORREO_DE_CANCHA';

-- Limpieza opcional de eventos antiguos (programa o ejecuta de vez en cuando):
-- delete from public.cancha_client_events where created_at < now() - interval '30 days';
