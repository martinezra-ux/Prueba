// @ts-nocheck
// Avisa por push cuando marca un equipo favorito. Ejecutar cada minuto (ver LEEME).
import { createClient } from "npm:@supabase/supabase-js@2";
import webpush from "npm:web-push@3.6.7";

const LEAGUES = ["esp.1","esp.2","esp.copa_del_rey","eng.1","eng.2","ita.1","ger.1","fra.1","uefa.champions","uefa.europa","uefa.europa.conf","por.1","ned.1","fifa.world","uefa.euro","uefa.nations","conmebol.america","fifa.friendly"];

Deno.serve(async () => {
  const sb = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SERVICE_ROLE_KEY")!);
  webpush.setVapidDetails("mailto:" + Deno.env.get("VAPID_CONTACT")!, Deno.env.get("VAPID_PUBLIC")!, Deno.env.get("VAPID_PRIVATE")!);
  const { data: subs } = await sb.from("cancha_push_subscriptions").select("*");
  if (!subs?.length) return new Response("sin suscriptores");
  const { data: prefs } = await sb.from("cancha_user_preferences").select("user_id,favorite_teams");
  const favs = new Map((prefs ?? []).map((p) => [p.user_id, (p.favorite_teams ?? []).map(String)]));
  let sent = 0;
  for (const lg of LEAGUES) {
    const r = await fetch(`https://site.api.espn.com/apis/site/v2/sports/soccer/${lg}/scoreboard`).catch(() => null);
    if (!r?.ok) continue;
    const j = await r.json();
    for (const ev of j.events ?? []) {
      if (ev.status?.type?.state !== "in") continue;
      const cs = ev.competitions?.[0]?.competitors ?? [];
      const h = cs.find((c) => c.homeAway === "home"), a = cs.find((c) => c.homeAway === "away");
      if (!h || !a) continue;
      const hs = Number(h.score || 0), as = Number(a.score || 0);
      const { data: st } = await sb.from("cancha_goal_state").select("*").eq("match_key", ev.id).maybeSingle();
      await sb.from("cancha_goal_state").upsert({ match_key: ev.id, home_score: hs, away_score: as, updated_at: new Date().toISOString() });
      if (!st || (hs <= st.home_score && as <= st.away_score)) continue; // sin gol nuevo
      const ids = [String(h.team.id), String(a.team.id)];
      const payload = JSON.stringify({ title: "¡GOL!", body: `${h.team.displayName} ${hs} - ${as} ${a.team.displayName}`, url: "/" });
      for (const s of subs) {
        if (!ids.some((t) => (favs.get(s.user_id) ?? []).includes(t))) continue;
        try {
          await webpush.sendNotification({ endpoint: s.endpoint, keys: { p256dh: s.p256dh, auth: s.auth } }, payload);
          sent++;
        } catch (e) {
          if (e.statusCode === 404 || e.statusCode === 410) await sb.from("cancha_push_subscriptions").delete().eq("endpoint", s.endpoint);
        }
      }
    }
  }
  return new Response("enviadas: " + sent);
});
