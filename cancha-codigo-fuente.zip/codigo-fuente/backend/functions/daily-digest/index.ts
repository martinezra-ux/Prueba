// @ts-nocheck
// Resumen diario por correo (solo a quien lo activó). Ejecutar una vez al día (ver LEEME).
import { createClient } from "npm:@supabase/supabase-js@2";

const SITE = "https://cancha-resultados-directo.netlify.app";
const LEAGUES = ["esp.1","esp.2","esp.copa_del_rey","eng.1","eng.2","ita.1","ger.1","fra.1","uefa.champions","uefa.europa","uefa.europa.conf","por.1","ned.1","fifa.world","uefa.euro","uefa.nations","conmebol.america","fifa.friendly"];

Deno.serve(async () => {
  const sb = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SERVICE_ROLE_KEY")!);
  const { data: users } = await sb.from("cancha_email_prefs").select("user_id").eq("daily_digest", true);
  if (!users?.length) return new Response("sin suscriptores");
  const ymd = new Date().toISOString().slice(0, 10).replace(/-/g, "");
  const events = [];
  for (const lg of LEAGUES) {
    const r = await fetch(`https://site.api.espn.com/apis/site/v2/sports/soccer/${lg}/scoreboard?dates=${ymd}`).catch(() => null);
    if (r?.ok) events.push(...((await r.json()).events ?? []));
  }
  let sent = 0;
  for (const u of users) {
    const { data: pref } = await sb.from("cancha_user_preferences").select("favorite_teams").eq("user_id", u.user_id).maybeSingle();
    const ids = (pref?.favorite_teams ?? []).map(String);
    const mine = events.filter((ev) => (ev.competitions?.[0]?.competitors ?? []).some((c) => ids.includes(String(c.team?.id))));
    if (!mine.length) continue;
    const { data: au } = await sb.auth.admin.getUserById(u.user_id);
    const to = au?.user?.email;
    if (!to) continue;
    const rows = mine.map((ev) => {
      const c = ev.competitions[0].competitors;
      const h = c.find((x) => x.homeAway === "home"), a = c.find((x) => x.homeAway === "away");
      const hora = new Date(ev.date).toLocaleTimeString("es-ES", { hour: "2-digit", minute: "2-digit", timeZone: "Europe/Madrid" });
      const marcador = ev.status.type.state === "pre" ? "vs" : `${h.score} - ${a.score}`;
      return `<li>${hora} · ${h.team.displayName} ${marcador} ${a.team.displayName}</li>`;
    }).join("");
    const html = `<h2>Tus equipos hoy</h2><ul>${rows}</ul><p style="font-size:12px;color:#666">Recibes este correo porque activaste el resumen diario en Cancha.fut. Puedes desactivarlo en <a href="${SITE}/perfil">tu perfil</a>.</p>`;
    const r = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { Authorization: `Bearer ${Deno.env.get("RESEND_API_KEY")}`, "Content-Type": "application/json" },
      body: JSON.stringify({ from: Deno.env.get("MAIL_FROM"), to, subject: "Tus equipos hoy · Cancha.fut", html, headers: { "List-Unsubscribe": `<${SITE}/perfil>` } }),
    });
    if (r.ok) sent++;
  }
  return new Response("enviados: " + sent);
});
