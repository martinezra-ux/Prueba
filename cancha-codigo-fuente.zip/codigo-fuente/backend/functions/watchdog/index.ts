// @ts-nocheck
// Vigilante: comprueba web, datos y cuentas, y te avisa SOLO cuando algo cae o se recupera.
// Programar cada 5 minutos (ver LEEME-alertas-y-seguridad.md).
import { createClient } from "npm:@supabase/supabase-js@2";

const SITE = Deno.env.get("SITE_URL") ?? "https://cancha-resultados-directo.netlify.app";
const SUPA = Deno.env.get("SUPABASE_URL")!;
const ANON = Deno.env.get("PUBLISHABLE_KEY") ?? "";
const CHECKS: [string, string, Record<string, string>?][] = [
  ["Web", SITE + "/"],
  ["ESPN", "https://site.api.espn.com/apis/site/v2/sports/soccer/esp.1/scoreboard"],
  ["SportScore", "https://sportscore.com/api/v1/search/?sport=football&q=real&limit=1"],
  ["Supabase", SUPA + "/auth/v1/health", { apikey: ANON }],
];

async function notify(text: string) {
  const to = Deno.env.get("ALERT_EMAIL") ?? "helpcancha.fut@gmail.com";
  const tg = Deno.env.get("TELEGRAM_TOKEN"), chat = Deno.env.get("TELEGRAM_CHAT_ID");
  if (tg && chat) await fetch(`https://api.telegram.org/bot${tg}/sendMessage`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ chat_id: chat, text }) }).catch(() => {});
  const rk = Deno.env.get("RESEND_API_KEY"), from = Deno.env.get("MAIL_FROM");
  if (rk && from) await fetch("https://api.resend.com/emails", { method: "POST", headers: { Authorization: `Bearer ${rk}`, "Content-Type": "application/json" }, body: JSON.stringify({ from, to, subject: "Cancha.fut · alerta", text }) }).catch(() => {});
}

Deno.serve(async () => {
  const sb = createClient(SUPA, Deno.env.get("SERVICE_ROLE_KEY")!);
  const out: string[] = [];
  for (const [name, url, headers] of CHECKS) {
    let ok = false;
    try { const r = await fetch(url, { headers, signal: AbortSignal.timeout(10000) }); ok = r.ok; } catch { ok = false; }
    const { data: st } = await sb.from("cancha_alert_state").select("down").eq("name", name).maybeSingle();
    const wasDown = !!st?.down;
    if (!ok && !wasDown) await notify(`🔴 Cancha.fut: ${name} NO responde (${new Date().toLocaleString("es-ES", { timeZone: "Europe/Madrid" })}).`);
    if (ok && wasDown) await notify(`✅ Cancha.fut: ${name} vuelve a funcionar.`);
    await sb.from("cancha_alert_state").upsert({ name, down: !ok, updated_at: new Date().toISOString() });
    out.push(`${name}: ${ok ? "ok" : "CAÍDO"}`);
  }
  return new Response(out.join("\n"));
});
