// @ts-nocheck
// Caché compartida de datos deportivos: todos los visitantes leen de aquí y la función consulta ESPN/SportScore como mucho una vez cada pocos segundos.
// Despliegue: supabase functions deploy data --no-verify-jwt
const ALLOW = ["site.api.espn.com", "site.web.api.espn.com", "sportscore.com"];
const cache = new Map<string, { t: number; body: string }>();
const ttl = (u: string) => /scoreboard|summary|live|fixtures|matches|events/i.test(u) ? 15000 : /search/i.test(u) ? 600000 : /standings|teams|roster|schedule|topscorers|news|player/i.test(u) ? 300000 : 60000;
const cors = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "apikey, authorization, content-type" };

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: cors });
  if (req.method !== "GET") return new Response("method", { status: 405, headers: cors });
  const u = new URL(req.url).searchParams.get("u") || "";
  let t: URL;
  try { t = new URL(u); } catch { return new Response("bad url", { status: 400, headers: cors }); }
  if (t.protocol !== "https:" || !ALLOW.includes(t.hostname)) return new Response("forbidden", { status: 403, headers: cors });
  const hit = cache.get(u), now = Date.now();
  const headers = { ...cors, "Content-Type": "application/json", "Cache-Control": "public, max-age=10" };
  if (hit && now - hit.t < ttl(u)) return new Response(hit.body, { headers: { ...headers, "X-Cache": "hit" } });
  try {
    const r = await fetch(u, { signal: AbortSignal.timeout(8000), headers: { "User-Agent": "Cancha.fut/1.0" } });
    if (!r.ok) throw new Error(String(r.status));
    const body = await r.text();
    if (body.length < 2_000_000) cache.set(u, { t: now, body });
    if (cache.size > 500) cache.delete(cache.keys().next().value);
    return new Response(body, { headers: { ...headers, "X-Cache": "miss" } });
  } catch (e) {
    if (hit) return new Response(hit.body, { headers: { ...headers, "X-Cache": "stale" } });
    return new Response("upstream", { status: 502, headers: cors });
  }
});
