# Caché compartida de datos (opcional, recomendado si llega mucha gente)

Ahora cada visitante pide los datos a ESPN y SportScore desde su navegador. Con esta función, todos leen de una sola caché.

1. En Supabase: Edge Functions > crea la función `data` con `functions/data/index.ts` y despliégala con `supabase functions deploy data --no-verify-jwt`.
2. Tu dirección será `https://TU_PROYECTO.supabase.co/functions/v1/data`.
3. En tu archivo `cancha-account-config.js` añade, dentro del objeto, `dataProxy:'https://TU_PROYECTO.supabase.co/functions/v1/data'` y sube ese archivo.
4. Si la función falla, la web pide los datos directamente como ahora y usa la copia guardada: no se rompe nada.
