-- Cancha.fut · avisos push y correos (Supabase > SQL Editor > Run). Seguro de repetir.
create table if not exists public.cancha_push_subscriptions (
  id bigserial primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  endpoint text not null unique,
  p256dh text not null,
  auth text not null,
  created_at timestamptz not null default now()
);
create table if not exists public.cancha_email_prefs (
  user_id uuid primary key references auth.users(id) on delete cascade,
  daily_digest boolean not null default false,
  consent_at timestamptz,
  updated_at timestamptz not null default now()
);
create table if not exists public.cancha_goal_state (
  match_key text primary key,
  home_score int not null default 0,
  away_score int not null default 0,
  updated_at timestamptz not null default now()
);

alter table public.cancha_push_subscriptions enable row level security;
alter table public.cancha_email_prefs enable row level security;
alter table public.cancha_goal_state enable row level security;  -- sin políticas: solo la función (service role)

drop policy if exists "push_own_all" on public.cancha_push_subscriptions;
create policy "push_own_all" on public.cancha_push_subscriptions for all to authenticated
  using (auth.uid() = user_id) with check (auth.uid() = user_id);
drop policy if exists "email_own_all" on public.cancha_email_prefs;
create policy "email_own_all" on public.cancha_email_prefs for all to authenticated
  using (auth.uid() = user_id) with check (auth.uid() = user_id);

grant select, insert, update, delete on public.cancha_push_subscriptions to authenticated;
grant select, insert, update, delete on public.cancha_email_prefs to authenticated;
