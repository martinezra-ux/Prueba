# Avisos push y correos: puesta en marcha

Todo esto está APAGADO en la web hasta que lo configures. No se ha probado en producción.

## 1. Base de datos
Supabase > SQL Editor: pega `supabase-notificaciones.sql` y pulsa Run.

## 2. Avisos de gol con la web cerrada (push)
1. En tu ordenador: `npx web-push generate-vapid-keys` (te da una clave pública y una privada).
2. En Supabase > Edge Functions > Secrets, crea: `SERVICE_ROLE_KEY` (la clave service_role del proyecto; NUNCA en la web),
   `VAPID_PUBLIC`, `VAPID_PRIVATE`, `VAPID_CONTACT` (tu correo).
3. Crea la función `notify-goals` con el contenido de `functions/notify-goals/index.ts` y despliégala
   (`supabase functions deploy notify-goals`).
4. Prográmala cada minuto (Edge Functions > Schedules, o pg_cron + pg_net).
5. En `index.html`, busca `PUSH_PUBLIC_KEY=''` y pon dentro la clave pública. Sube `index.html`.
   En el perfil aparecerá "Activar avisos con la web cerrada".
Nota: en iPhone solo funcionan si la web está añadida a la pantalla de inicio.

## 3. Resumen diario por correo
1. Crea cuenta en Resend (u otro servicio) y verifica un dominio tuyo para enviar desde él.
2. Secretos: `RESEND_API_KEY`, `MAIL_FROM` (por ejemplo `Cancha.fut <avisos@tudominio.com>`), y los de Supabase.
3. Crea la función `daily-digest` con `functions/daily-digest/index.ts` y prográmala una vez al día (por ejemplo, 08:00).
4. En `index.html`, cambia `EMAIL_ON=false` por `EMAIL_ON=true`. En el perfil aparecerá la casilla de consentimiento.
5. Actualiza la política de privacidad: menciona el servicio de correo, push y la base legal (consentimiento).
