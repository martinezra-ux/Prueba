import re,hashlib,os,glob,shutil,zipfile,subprocess,html
W='/home/claude/web';S='/home/claude/site';U='/mnt/user-data/uploads'
os.chdir(W)
shutil.rmtree(S,ignore_errors=True);os.makedirs(S+'/assets');os.makedirs(S+'/guias');os.makedirs(S+'/sounds')
SPA=['index','partidos','directo','clasificaciones','favoritos','noticias','fichajes']
cssset=set();jsset=set();outs={}
for n in SPA:
    t=open(f'{n}.html',encoding='utf-8',newline='').read()
    hb=t.index('</head>')
    styles=[m for m in re.finditer(r'<style([^>]*)>(.*?)</style>',t,re.S) if not m.group(2).startswith('html,body{background')]
    scripts=[m for m in re.finditer(r'<script>(.*?)</script>',t,re.S) if m.start()>hb]
    css='\n'.join(m.group(2) for m in styles);js='\n;\n'.join(m.group(1) for m in scripts)
    cssset.add(css);jsset.add(js);outs[n]=(t,styles,scripts)
assert len(cssset)==1 and len(jsset)==1,('las copias no comparten CSS/JS',len(cssset),len(jsset))
css=cssset.pop();js=jsset.pop()
hc=hashlib.sha1(css.encode()).hexdigest()[:8];hj=hashlib.sha1(js.encode()).hexdigest()[:8]
open(f'{S}/assets/app.{hc}.css','w',encoding='utf-8').write(css);open(f'{S}/assets/app.{hj}.js','w',encoding='utf-8').write(js)
for n,(t,styles,scripts) in outs.items():
    ops=[(styles[0].start(),styles[0].end(),f'<link rel="stylesheet" href="/assets/app.{hc}.css">')]+[(m.start(),m.end(),'') for m in styles[1:]]
    ops+=[(scripts[0].start(),scripts[0].end(),f'<script src="/assets/app.{hj}.js"></script>')]+[(m.start(),m.end(),'') for m in scripts[1:]]
    for a,b,r in sorted(ops,reverse=True): t=t[:a]+r+t[b:]
    open(f'{S}/{n}.html','w',encoding='utf-8',newline='').write(t)
# el JS unido debe compilar como un solo script global (detecta declaraciones repetidas)
r=subprocess.run(['node','-e',f"const vm=require('vm'),fs=require('fs');try{{new vm.Script(fs.readFileSync('{S}/assets/app.{hj}.js','utf8'));console.log('JS unido compila bien')}}catch(e){{console.log('ERROR JS unido:',e.message);process.exit(1)}}"],capture_output=True,text=True);print(r.stdout.strip(),r.stderr.strip()[:300])
assert r.returncode==0
# resto de archivos
rest=['equipos','competiciones','sobre-nosotros','contacto','Cancha-Privacidad','Cancha-Terminos','Cancha-Fuentes','admin','404','offline']
for n in rest: shutil.copy(f'{n}.html',S)
for g in glob.glob('guias/*.html'): shutil.copy(g,S+'/guias/')
for f in ['ads.js','i18n.js','_redirects','robots.txt','humans.txt','sw.js']: shutil.copy(f,S)
for f in ['manifest.webmanifest','cancha-logo.png','cancha-favicon.png','apple-touch-icon.png','icon-192.png','icon-512.png']: shutil.copy('pwa/'+f,S)
for f in ['ads.txt','cancha-account-config.js','cancha-logo-ads.png']: shutil.copy(f'{U}/{f}',S)
for f in ['football-ambience.mp3','football-crowd-goal.mp3','football-goal-cheer.mp3']: shutil.copy(f'{U}/{f}',S+'/sounds/')
h=open('_headers').read()
if '/assets/' not in h: h=h.rstrip('\n')+'\n/assets/*\n  Cache-Control: public, max-age=31536000, immutable\n'
open(S+'/_headers','w').write(h)
sm=open('sitemap.xml',encoding='utf-8').read();B='https://cancha-resultados-directo.netlify.app'
clubs=sorted(set(re.findall(r'href="(/equipo/[^"]+)"',open('equipos.html',encoding='utf-8').read())))
sm=re.sub(r'  <url><loc>[^<]*/equipo/[^<]*</loc></url>\n','',sm)
sm=sm.replace('</urlset>',''.join(f'  <url><loc>{B}{c}</loc></url>\n' for c in clubs)+'</urlset>')
open(S+'/sitemap.xml','w',encoding='utf-8').write(sm)
# comprobaciones
refs=set()
for f in glob.glob(S+'/**/*.html',recursive=True)+glob.glob(S+'/*.js')+glob.glob(S+'/assets/*')+[S+'/manifest.webmanifest',S+'/sw.js']:
    t=open(f,encoding='utf-8',errors='ignore').read()
    refs|=set(re.findall(r'["\'(](/[A-Za-z0-9_\-./]+\.(?:png|jpg|svg|js|css|mp3|webmanifest|html|txt|xml|ico))(?:\?[^"\')]*)?["\')]',t))
missing=sorted(x for x in refs if not os.path.exists(S+x))
print('referencias:',len(refs),'| faltan:',missing or 'ninguna')
for n in ['index','partidos','equipos']: print(f'{n}.html:',os.path.getsize(f'{S}/{n}.html')//1024,'KB')
print('app.css',os.path.getsize(f'{S}/assets/app.{hc}.css')//1024,'KB | app.js',os.path.getsize(f'{S}/assets/app.{hj}.js')//1024,'KB')
allf=sorted(os.path.relpath(os.path.join(d,x),S) for d,_,fs in os.walk(S) for x in fs)
zp='/mnt/user-data/outputs/cancha-sitio-completo.zip'
if os.path.exists(zp):os.remove(zp)
with zipfile.ZipFile(zp,'w',zipfile.ZIP_DEFLATED) as z:
    for f in allf: z.write(f'{S}/{f}','cancha-sitio/'+f)
print('sitio:',len(allf),'archivos |',os.path.getsize(zp)//1024,'KB')
zs='/mnt/user-data/outputs/cancha-codigo-fuente.zip'
if os.path.exists(zs):os.remove(zs)
with zipfile.ZipFile(zs,'w',zipfile.ZIP_DEFLATED) as z:
    for f in ['index.html','build_content.py','build_guides2.py','build_final.py','build_site.py','i18n.js','ads.js','sw.js','offline.html','_headers','_redirects']: z.write(f,'codigo-fuente/'+f)
    for d,_,fs in os.walk('backend'):
        for x in fs: z.write(os.path.join(d,x),'codigo-fuente/'+os.path.join(d,x))
print('código fuente:',os.path.getsize(zs)//1024,'KB')
