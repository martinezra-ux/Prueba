/* Cancha.fut · control de anuncios. ESTÁ APAGADO: no hace nada hasta que pongas ADS_ENABLED=true. */
(function(){
var ADS_ENABLED=false,CLIENT='ca-pub-5811747646575753',SLOT_ARTICLE='',MIN_WORDS=400;
var p=location.pathname.replace(/\/+$/,'')||'/';
/* NUNCA en pantallas funcionales, de carga, de alertas, de navegación ni de error */
var BLOCK=/^\/(perfil|favoritos|admin(\.html)?|404(\.html)?)$/;
/* Solo en páginas de lectura con contenido propio */
var ALLOW=[/^\/guias\/.+/,/^\/competiciones$/,/^\/equipos$/,/^\/sobre-nosotros(\.html)?$/];
if(!ADS_ENABLED||BLOCK.test(p)||!ALLOW.some(function(r){return r.test(p)}))return;
function go(){
 if(((document.body.innerText||'').trim().split(/\s+/).length)<MIN_WORDS)return; /* contenido suficiente */
 var s=document.createElement('script');s.async=true;s.crossOrigin='anonymous';
 s.src='https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client='+CLIENT;document.head.appendChild(s);
 var host=document.querySelector('article');if(!host||!SLOT_ARTICLE)return;
 var h=host.querySelectorAll('h2'),at=h[Math.min(1,h.length-1)];if(!at)return;
 var ins=document.createElement('ins');ins.className='adsbygoogle';ins.style.display='block';
 ins.setAttribute('data-ad-client',CLIENT);ins.setAttribute('data-ad-slot',SLOT_ARTICLE);ins.setAttribute('data-ad-format','auto');ins.setAttribute('data-full-width-responsive','true');
 at.parentNode.insertBefore(ins,at);(window.adsbygoogle=window.adsbygoogle||[]).push({});
}
if(document.readyState==='complete')go();else addEventListener('load',go);
})();
