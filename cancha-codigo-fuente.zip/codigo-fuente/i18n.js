/* Cancha.fut · traducción automática (Google Translate). Solo se carga si la persona elige un idioma distinto del español. */
(function(){
var L={es:'Español',en:'English',fr:'Français',pt:'Português',it:'Italiano',de:'Deutsch'},K='cancha-prefs-v1';
function get(){try{return JSON.parse(localStorage.getItem(K)||'{}').lang||'es'}catch(e){return 'es'}}
function put(c){try{var p=JSON.parse(localStorage.getItem(K)||'{}');p.lang=c;localStorage.setItem(K,JSON.stringify(p))}catch(e){}}
function cookie(c){var h=location.hostname,v=c==='es'?'':'/es/'+c,past=c==='es'?'; expires=Thu, 01 Jan 1970 00:00:00 GMT':'';['','; domain='+h,'; domain=.'+h].forEach(function(d){document.cookie='googtrans='+v+'; path=/'+d+past})}
window.canchaSetLang=function(c){if(!L[c])c='es';put(c);cookie(c);location.reload()};
var cur=get();
if(cur!=='es'&&L[cur]){cookie(cur);
 var d=document.createElement('div');d.id='gt-el';d.style.display='none';document.addEventListener('DOMContentLoaded',function(){document.body.appendChild(d)});
 window.googleTranslateElementInit=function(){new google.translate.TranslateElement({pageLanguage:'es',includedLanguages:'en,fr,pt,it,de',autoDisplay:false},'gt-el')};
 var s=document.createElement('script');s.src='https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit';s.async=true;document.head.appendChild(s)}
function build(){var f=document.querySelector('footer');if(!f||document.getElementById('lang-select'))return;var w=document.createElement('p');w.className='lang-box notranslate';w.innerHTML='<label>Idioma: <select id="lang-select" aria-label="Idioma">'+Object.keys(L).map(function(k){return '<option value="'+k+'"'+(k===cur?' selected':'')+'>'+L[k]+'</option>'}).join('')+'</select></label>';f.appendChild(w);document.getElementById('lang-select').onchange=function(){window.canchaSetLang(this.value)}}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',build);else build();
var st=document.createElement('style');st.textContent='.goog-te-banner-frame,.goog-te-balloon-frame,#goog-gt-tt,.goog-tooltip,iframe.skiptranslate{display:none!important}body{top:0!important}.goog-text-highlight{background:none!important;box-shadow:none!important}.lang-box{margin:10px 0 0;font-size:13px}.lang-box select{background:transparent;color:inherit;border:1px solid currentColor;border-radius:6px;padding:2px 6px}';document.head.appendChild(st);
})();
